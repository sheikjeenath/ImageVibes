from transformers import BlipProcessor, BlipForConditionalGeneration
from PIL import Image
import torch

print("All libraries imported successfully!")
